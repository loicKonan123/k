﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using CombatServeurSocketElfe.Classes;

namespace CombatServeurSocketElfe
{
    public partial class frmServeurSocketElfe : Form
    {
        Random m_r;
        Nain m_nain;
        Elfe m_elfe;
        TcpListener m_ServerListener;
        Socket m_client;
      

        public frmServeurSocketElfe()
        {
            InitializeComponent();
            m_r = new Random();

            btnReset.Enabled = false;
            //Démarre un serveur de socket (TcpListener)

            m_ServerListener = new TcpListener(IPAddress.Parse("127.0.0.1"), 9999);
            m_ServerListener.Start();

            Reset();
         
            lstReception.Items.Add("Serveur démarré !");
            lstReception.Items.Add("PRESSER : << attendre un client >>");
            lstReception.Update();
            Control.CheckForIllegalCrossThreadCalls = false;
        }
        void Reset()
        {
            m_nain = new Nain(1, 0, 0);
            picNain.Image = m_nain.Avatar;
            AfficheStatNain();

            m_elfe = new Elfe(m_r.Next(10, 20), m_r.Next(2, 6), m_r.Next(2, 6));
            picElfe.Image = m_elfe.Avatar;
            AfficheStatElfe();
 
            lstReception.Items.Clear();
        }
        void AfficheStatNain()
        {
            lblVieNain.Text = "vie:" + m_nain.Vie;
            lblForceNain.Text = "force:" + m_nain.Force;
            lblArmeNain.Text = "arme :" + m_nain.Arme;

            this.Update(); // pour s'assurer de l'affichage via le thread
        }
        void AfficheStatElfe()
        {
            lblVieElfe.Text = "vie:" + m_elfe.Vie;
            lblForceElfe.Text = "force:" + m_elfe.Force;
            lblSortElfe.Text = "sort:" + m_elfe.Sort;

            this.Update(); // pour s'assurer de l'affichage via le thread
        }
        private void btnReset_Click(object sender, EventArgs e)
        {
            Reset();
        }     

        private void btnAttente_Click(object sender, EventArgs e)
        {
            // Combat par un thread
            ThreadStart CodeThread = new ThreadStart (Combat);
            Thread monThread = new Thread(CodeThread);
            monThread.Start();
        }
        public void Combat() 
        {
            // déclarations de variables locales 
            byte[] tbyteReception = new byte[20];
            int nbOctetReception;
            string receptionClient;
            byte[] tbyteEnvoi = new byte[50];
            string Envoiestat = "aucune";
            int ngOctetEnvoie;
            string[] tRecup;
            ASCIIEncoding textByte = new ASCIIEncoding();
            
            try
            {   while(m_nain.Vie>0 && m_elfe.Vie > 0)
                {
                    m_client = m_ServerListener.AcceptSocket();
                    // tous le code de traitement
                    lstReception.Items.Add("client branché");
                    lstReception.Update();
                    Thread.Sleep(500);
                    btnAttente.Enabled = false;
                    nbOctetReception = m_client.Receive(tbyteReception);
                    receptionClient = Encoding.ASCII.GetString(tbyteReception);
                 
                    lstReception.Items.Add("du client:" + receptionClient);
                    lstReception.Update();

                    tRecup = receptionClient.Split(';');
                  
                    m_nain.Vie = Convert.ToInt32(tRecup[0]);
                    m_nain.Force = Convert.ToInt32(tRecup[1]);
                    m_nain.Arme =tRecup[2];
                    AfficheStatNain();

                    MessageBox.Show("serveur :  frapper elfe");
                    m_nain.Frapper(m_elfe);
                    MessageBox.Show("serveur: lancer sort  nain");
                    m_elfe.LancerSort(m_nain);

                    AfficheStatElfe();
                    AfficheStatNain();

                    Envoiestat = m_nain.Vie.ToString() + ";" + m_nain.Force + ";" + m_nain.Arme + ";" + m_elfe.Vie + ";" + m_elfe.Force + ";" + m_elfe.Sort;
                    tbyteEnvoi = textByte.GetBytes(Envoiestat);
                    ngOctetEnvoie = m_client.Send(tbyteEnvoi);

                    if (m_nain.Vie > m_elfe.Vie && m_elfe.Vie <= 0)
                    {
                        MessageBox.Show("le gagnant est le nain");
                        return;
                    }
                    else if (m_elfe.Vie > m_nain.Vie && m_nain.Vie <= 0)
                    {
                        MessageBox.Show("le gagnant est le l'elfe");
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception: " + ex.Message);
            }
        }

        private void btnFermer_Click(object sender, EventArgs e)
        {
            // il faut avoir un objet elfe et un objet nain instanciés
            m_elfe.Vie = 0;
            m_nain.Vie = 0;
            try
            {
                Thread.Sleep(1000);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception: " + ex.Message);
            }
        }

        private void frmServeurSocketElfe_FormClosing(object sender, FormClosingEventArgs e)
        {
            btnFermer_Click(sender,e);
            try
            {
                // il faut avoir un objet TCPListener existant
                 m_ServerListener.Stop();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception: " + ex.Message);
            }
        }
    }
}
