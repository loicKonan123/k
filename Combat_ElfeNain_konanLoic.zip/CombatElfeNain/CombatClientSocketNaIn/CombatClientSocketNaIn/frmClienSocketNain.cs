﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using CombatClientSocketNaIn.Classes;


namespace CombatClientSocketNaIn
{
    public partial class frmClienSocketNain : Form
    {

        Random m_r;
        Elfe m_elfe;
        Nain m_nain;
        public frmClienSocketNain()
        {
            InitializeComponent();
            m_r = new Random();
            Reset();
            btnReset.Enabled = false;
            Control.CheckForIllegalCrossThreadCalls = false;
        }
        void Reset()
        {
            m_nain = new Nain(m_r.Next(10, 20), m_r.Next(2, 6), m_r.Next(0, 3));
            picNain.Image = m_nain.Avatar;
            lblVieNain.Text = "Vie: " + m_nain.Vie.ToString(); ;
            lblForceNain.Text = "Force: " + m_nain.Force.ToString();
            lblArmeNain.Text = "Arme: " + m_nain.Arme;

            m_elfe = new Elfe(1, 0, 0);
            picElfe.Image = m_elfe.Avatar;
            lblVieElfe.Text = "Vie: " + m_elfe.Vie.ToString();
            lblForceElfe.Text = "Force: " + m_elfe.Force.ToString();
            lblSortElfe.Text = "Sort: " + m_elfe.Sort.ToString();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {

            btnFrappe.Enabled = true;
            Reset();
        }

        private void btnFrappe_Click(object sender, EventArgs e)
        {
            Socket Client;
            byte[] tByteReception = new byte[100];
            int nbOctetReception;
            string Envoiestat;
            string reponse;
            byte[] tbyteEnvoi = new byte[20];
            ASCIIEncoding textByte = new ASCIIEncoding();
            string [] tRecup;

            try
            {
                Client = new Socket(SocketType.Stream, ProtocolType.Tcp);
                Client.Connect(IPAddress.Parse("127.0.0.1"), 9999);

                if (Client.Connected)
                {
                    Envoiestat = m_nain.Vie.ToString() + ";" + m_nain.Force + ";" + m_nain.Arme;
                    tbyteEnvoi = textByte.GetBytes(Envoiestat);
                    MessageBox.Show("client:" + Envoiestat);

                    Client.Send(tbyteEnvoi);

                    Thread.Sleep(500);
                    nbOctetReception = Client.Receive(tByteReception);
                    reponse = Encoding.ASCII.GetString(tByteReception);
                    MessageBox.Show("\r\nReception .. ."+ reponse);

                    tRecup = reponse.Split(';');

                    lblVieNain.Text ="vie:"+ tRecup[0];
                    lblForceNain.Text = "force:" + tRecup[1];
                    lblArmeNain.Text = "arme :" + tRecup[2];

                    lblVieElfe.Text= "vie:" + tRecup[3];
                    lblSortElfe.Text= "Sort:" + tRecup[5];
                    lblForceElfe.Text= "force :" + tRecup[4];

                    m_nain.Vie = Convert.ToInt32(tRecup[0]);
                    m_nain.Force = Convert.ToInt32(tRecup[1]);
                    m_nain.Arme = tRecup[2];

                    m_elfe.Vie = Convert.ToInt32(tRecup[3]);
                    m_elfe.Sort = Convert.ToInt32(tRecup[4]);
                    m_elfe.Force =Convert.ToInt32(tRecup[5]);

                    if (m_nain.Vie > m_elfe.Vie && m_elfe.Vie <= 0)
                    {
                        btnFrappe.Enabled = false;
                        MessageBox.Show("le gagnant est le nain");
                        return;
                    }
                    else if (m_elfe.Vie > m_nain.Vie && m_nain.Vie <= 0)
                    {
                        btnFrappe.Enabled = false;
                        MessageBox.Show("le gagnant est l'elfe");
                        return;
                    }
                }
                Client.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
